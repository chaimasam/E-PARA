/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.io.Serializable;
import javax.persistence.Embeddable;

/**
 *
 * @author Lachgar
 */
@Embeddable
public class LigneCommandePK implements Serializable{
    private int produitId;
    private int commandeId;

    public LigneCommandePK() {
    }

    public LigneCommandePK(int produitId, int commandeId) {
        this.produitId = produitId;
        this.commandeId = commandeId;
    }
    

    public int getProduitId() {
        return produitId;
    }

    public void setProduitId(int produitId) {
        this.produitId = produitId;
    }

    public int getCommandeId() {
        return commandeId;
    }

    public void setCommandeId(int commandeId) {
        this.commandeId = commandeId;
    }
    
    
    
}
