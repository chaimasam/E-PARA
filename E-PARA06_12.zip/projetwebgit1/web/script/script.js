function showMatricule (){
    var matricule = document.getElementById("profm");
    matricule.style.display = "none";
    var cne = document.getElementById("etdc");
    cne.style.display = "table-row";
}

function showCne (){
    var cne = document.getElementById("etdc");
    cne.style.display = "none";
    var matricule = document.getElementById("profm");
    matricule.style.display = "table-row";
}

